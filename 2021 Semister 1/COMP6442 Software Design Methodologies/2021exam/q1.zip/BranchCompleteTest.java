import org.junit.Test;

public class BranchCompleteTest {

	@Test(timeout = 1000)
	public void test() {

		// TODO
		// START YOUR CODE
		// HINT: assertTrue(BranchComplete.findSomething(a, b, c));
		// OR assertFalse(BranchComplete.findSomething(a, b, c));

		// END YOUR CODE
	}
}
