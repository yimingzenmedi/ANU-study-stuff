
public abstract class Command {
}
