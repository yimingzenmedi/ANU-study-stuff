public class ComponentOutOfRangeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -971527662526187405L;
}
