package parser;
/**
 * Pointer direction
 * 
 */
public enum Direction {NORTH, EAST, WEST, SOUTH};
