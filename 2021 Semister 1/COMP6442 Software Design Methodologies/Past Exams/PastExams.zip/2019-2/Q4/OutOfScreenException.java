package parser;
/**
 * This exception represents issue with out of screen size.
 * 
 */
public class OutOfScreenException extends Exception {}
