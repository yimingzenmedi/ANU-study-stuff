package utils;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * TODO: write a minimum number of JUnit test cases (assertEquals) for
 * {@code MyUtil.parseDouble} that is code complete.
 * 
 * 
 *
 */
public class MyUtilTest {

	@Test
	public void test() {
		//start your code
		
		
		
		//end your code
	}

}
