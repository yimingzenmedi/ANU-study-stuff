
public class FileUtil {

	public static String getTableFileName(String tableName) {
		return tableName + ".xml";
	}
}
