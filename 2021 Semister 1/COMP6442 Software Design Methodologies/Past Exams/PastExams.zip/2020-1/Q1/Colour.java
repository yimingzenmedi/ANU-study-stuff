
public enum Colour {
	PINK, PURPLE, MAGENTA, VIOLET
}
