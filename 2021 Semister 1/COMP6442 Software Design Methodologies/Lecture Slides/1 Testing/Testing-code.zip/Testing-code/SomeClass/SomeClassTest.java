import static org.junit.Assert.*;

import org.junit.Test;

public class SomeClassTest {

	@Test
	public void test() {
		SomeClass.someMethod(true, true, true);
		//SomeClass.someMethod(false, true, true);
		//SomeClass.someMethod(false, false, false);
		
		//SomeClass.someMethod(true, true, false);
		//SomeClass.someMethod(false, true, false);
		//SomeClass.someMethod(false, false, true);
		
		
	}

}
