/**
 * This class is for marking purpose. Do not modify any code associated with the tracker.
 */

public class tracker {
    public static int counter = 0;

    public static void calltracking(int minX, int maxX, int minY, int maxY){
        counter++;
    }

}