public enum Colour {
	RED, BLACK;
}