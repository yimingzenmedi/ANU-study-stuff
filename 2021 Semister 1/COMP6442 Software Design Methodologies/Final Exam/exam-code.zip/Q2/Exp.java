/**
 * Abstract class Exp to represent expressions
 *
 * You are not required to implement any function inside this class.
 * Please do not change anything inside this class as well.
 */
public abstract class Exp {

	public abstract String show();
	public abstract int evaluate();
}
