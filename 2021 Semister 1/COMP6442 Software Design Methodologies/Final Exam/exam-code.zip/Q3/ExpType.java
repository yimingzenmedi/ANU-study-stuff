
public enum ExpType {
	AddExp, SubExp, MulExp, DivExp, ExpoExp, IntExp
}
