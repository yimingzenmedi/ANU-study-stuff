
public class Multiplicator {

	public Multiplicator() {
	}

	public long multiply(long x, long y) {
		return x * y;
	}
}
