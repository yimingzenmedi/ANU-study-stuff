/**
 * The given code is provided to assist you to complete the required tasks. But
 * the given code is often incomplete. You have to read and understand the given
 * code carefully, before you can apply the code properly. You might need to
 * implement additional procedures, such as error checking and handling, in
 * order to apply the code properly.
 */

public class KMultiplicator extends Multiplicator {

	private final Tracker tracker;

	public KMultiplicator(Tracker tracker) {
		this.tracker = tracker;
	}

	@Override
	public long multiply(long x, long y) {
		this.tracker.trace(x, y); // Do not modify this method. Otherwise, you will be penalized for violation.
		long result = 0;

		// ########## YOUR CODE STARTS HERE ##########

		// ########## YOUR CODE ENDS HERE ##########

		return result;
	}
}
