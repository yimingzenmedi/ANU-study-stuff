def contribution_statement():
    # TODO Add contribution / reference / collaboration statement as a string.
    statement = "Ziyang Chen (u6908560) mainly contributed on Section 1. Han Zhang (u7235649) mainly contributed on Section 2."

    return statement